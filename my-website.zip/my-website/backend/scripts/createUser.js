require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');

const users = [
    {
        username: 'admin',
        password: 'admin123',
        isAdmin: true
    },
    {
        username: 'Test',
        password: 'test',
        isAdmin: false
    },
    {
        username: 'user2',
        password: 'user456',
        isAdmin: false
    }
];

const createUsers = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        
        // Видаляємо всіх попередніх користувачів
        await User.deleteMany({});
        
        // Створюємо нових користувачів
        for (const userData of users) {
            const newUser = new User(userData);
            await newUser.save();
            console.log(`Користувача ${userData.username} успішно створено!`);
        }
        
    } catch (error) {
        console.error('Помилка при створенні користувачів:', error);
    } finally {
        await mongoose.connection.close();
    }
};

createUsers(); 